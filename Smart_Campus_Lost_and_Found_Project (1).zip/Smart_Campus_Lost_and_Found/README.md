# Smart Campus Lost & Found Management System

**Student:** ALFASANI COER  
**Roll Number:** cu26870025  
**Course:** BCA I Semester  
**Lab Sheet:** 10

## Objective
Develop a C++ system to report lost and found items, search records, match possible lost/found items, view and delete records, show statistics, and export a report.

## Files
- `main.cpp` — complete menu-driven C++ source code.
- `lost_found_records.txt` — created automatically when records are saved.
- `exported_report.txt` — created when Export Report is selected.

## Compile
```bash
g++ -std=c++11 main.cpp -o lost_found_app
```

## Run
```bash
./lost_found_app
```

On Windows, run:
```bash
lost_found_app.exe
```

## Demo login
- Username: `student`
- Password: `1234`

This is a classroom demonstration login, not a secure authentication system.

## Notes
The program stores records in a pipe-separated text file. Do not enter the `|` character in item details because it is used as the file separator. Auto-match compares item name and category exactly (ignoring uppercase/lowercase); every possible match must be verified by a student.
